# File Transfer Sample

## About

This sample demonstrates some of the file handling capabilities of Micro Integrator.

This sample contains an Inbound Endpoint called StudentDataFileProcessInboundEP which polls a particular location for available files. Also, it contains two sequences called StudentDataFileProcessSeq and StudentDataFileErrorSeq.

The file inbound endpoint listening on file path specified in the transport.vfs.FileURI parameter. The transport.vfs.FileNamePattern represent the file pattern to process. Once the file inbound endpoint read a file successfully, content is injected to the sequence for further mediation. In the sample, StudentDataFileProcessSeq logs the content of the received message.

Once read is successful, file will be moved to a location define in the transport.vfs.MoveAfterProcess parameter. If an error occurred while reading, then the file will be moved to the location specified in the transport.vfs.MoveAfterFailure parameter.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the FileTransfer_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.
4. Replace absolute folder paths in following properties (in StudentDataFileProcessInboundEP.xml)
```
<parameter name="transport.vfs.FileURI">file:///home/user/in</parameter>
<parameter name="transport.vfs.MoveAfterProcess">file:///home/user/out</parameter>
<parameter name="transport.vfs.MoveAfterFailure">file:///home/user/error</parameter>
```
5. Copy any .csv file to the ‘file:///home/user/in’ directory and you can see the content of the csv file logged in the MI server console. After processing the csv files, the files will be moved to the directory specified in transport.vfs.MoveAfterProcess parameter.


## License
This sample is licensed under the Apache License 2.0.

