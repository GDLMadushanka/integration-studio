# Scatter Gather Integration Sample

## About

This sample demonstrates how to implement Scatter-Gather enterprise integration pattern with Micro Integrator.

This sample contains a REST API called MissionServiceAPI and three endpoints MissionEP1, MissionEP2, and MissionEP3. 

The API clones the request payload and send it to three different endpoints. The responses are aggregated and built into a single payload and send back to the client.

## Deploying 
1. Download and start the latest Micro Integrator server.
https://mi.docs.wso2.com/en/latest/install-and-setup/install/running-the-mi/

2. Build the sample
3. Copy the ProxyingaSOAPService_1.0.0-SNAPSHOT.car to <MI_HOME>/repository/deployment/server/carbonapps location.

## How to invoke

```
curl --location 'http://localhost:8290/missionservice' --header 'Content-Type: text/xml' \
--data '<tem:Mission xmlns:tem="http://tempuri.org"/>'
```

## License
This sample is licensed under the Apache License 2.0.

